package Week_One_Core_Java.Day_One;
/*
Name - Sanket Kadam
Phone no - 8432338668
Email - sanketkadam9614@gmail.com
 */
public class PersonalIntro {
    public static void main(String[] args) {
        String myName = "Sanket Kadam";
        long phoneNo = 8432338868L ;
        String fav_prog_lang = "Java";

        System.out.println("hello world");
        System.out.println("My name is - " + myName);
        System.out.println("My contact no - " + phoneNo);
        System.out.println("Favorite programing lang is " + fav_prog_lang);
    }
}
//O/P
/*
hello world
My name is - Sanket Kadam
My contact no - 8432338868
Favorite programing lang is Java
 */